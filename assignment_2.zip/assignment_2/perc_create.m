function p= perc_create(n)
    p = rand(1,n+1);
end
